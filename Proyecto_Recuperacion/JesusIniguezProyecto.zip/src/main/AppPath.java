package main;

import java.io.File;

public class AppPath {
	@SuppressWarnings("unused")
	public static String DATA = "data";
	public static final String Empty = "emptywords"+File.separator+"emptywords";
	public static final String RES = "results"+File.separator;
	public static final String Corpus = "corpus";
}
