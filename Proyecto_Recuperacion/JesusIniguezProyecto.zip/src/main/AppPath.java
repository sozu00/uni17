package main;

import java.io.File;

public class AppPath {
	public static String DATA = "data";
	public static String Empty = "emptywords"+File.separator+"emptywords";
	public static String RES = "results"+File.separator;
	public static String Corpus = "corpus";
}
