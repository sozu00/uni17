package main;

import Proyector.Formateador;

import java.io.IOException;

public class principal {
	
	public static void main(final String[] args) throws IOException{
		Formateador F = new Formateador();
		F.showMenu();
	}
}
