package Filtros;

interface filtroGenerico {

	String ejecutar(String s);
}
