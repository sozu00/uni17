package Indexing;

public class AppPath {
	public static final String DATA = "/home/sozu00/REC-INF/uni17/Proyecto_Recuperacion/data";
	public static final String Empty = "/home/sozu00/REC-INF/uni17/Proyecto_Recuperacion/emptywords/emptywords";
	public static final String DATOSWindows = "D:\\uni17\\Proyecto_Recuperacion\\data";
	public static final String EmptyWindows = "D:\\uni17\\Proyecto_Recuperacion\\emptywords\\emptywords";
}
