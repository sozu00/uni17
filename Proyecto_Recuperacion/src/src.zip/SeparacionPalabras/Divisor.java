package SeparacionPalabras;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.*;


public class Divisor {
	
	public ArrayList<String> ejecutar(String s){
		ArrayList<String> T =  new ArrayList<String>(Arrays.asList(s.split(" ")));
		return T;
	}
}
