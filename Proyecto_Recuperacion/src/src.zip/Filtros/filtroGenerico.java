package Filtros;
/*
 * String ejecutar(String s)
 * 
 *  
 */


public interface filtroGenerico {

	public String ejecutar(String s);
}
