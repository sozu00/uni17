import Indexing.Indexing;

import java.io.IOException;

public class main {
	
	public static void main(String[] args) throws IOException{
		Indexing i = new Indexing();
		i.execute();
	}
	
	
}
